<!-- main screen -->
<div class="row mt-2">
    <div class="col-md-12 main">
        <br>

        <h3>
            Admin Login
        </h3>
        <hr>
        <form method="post">
            <div class="form-group m-2">
                <input type="text" name="user" class="form-control us" placeholder="Enter User Name" required>
            </div>
            <div class="form-group m-2">
                <input type="password" name="pass" class="form-control pass" placeholder="Enter Password" required>
            </div>
            <div class="form-group m-2">
                <input type="submit" name="login" class="bt-red" value="Login">
                <input type="reset" name="reset" class="bt-red" value="Reset">
            </div>
        </form>
    </div>
</div>
