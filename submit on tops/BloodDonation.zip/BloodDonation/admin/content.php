<?php 
if(!isset($_SESSION["a_id"]))
{
  echo "<script>
    window.location='./';
  </script>";
}
?>
<!-- main screen -->
<div class="row mt-2">
            <div class="col-md-12 main">
                <br>
                <h3>
                    Dashboard
                </h3>

                <hr>
                <div class="container">
                    <br>
                    <!-- content here -->
                </div>
            </div>
        </div>