<div class="col-md-12">
    <div class="row">
        <!-- this is main -->
        <div class="col-md-12 mainfile">
            <div class="container">
                <br>
                    <h3>
                        Error 404 !
                    </h3>
                    <hr>
                    <div>
                       <a href="<?php echo $mainurl;?>"><img style="width: 100%;height: 399px;" src="<?php echo $baseurl; ?>/image/1_zBFBJktPD3_z0S_35kO5Hg.gif"> </a>
                    </div>
               
            </div>
        </div>
    </div>
