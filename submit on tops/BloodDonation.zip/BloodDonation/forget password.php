<div class="col-md-12">
    <div class="row">
        <!-- this is main -->
        <div class="col-md-12 mainfile">
            <div class="container"><br>
                <h3>Forget Password</h3>
                <hr>
                <br>
                <form method="post">
                    <input type="text" name="email" class="form-control" placeholder="Enter your email address" required>
                    <input type="submit" name="forget" value="Forget Password" class="mt-2 btn btn-danger">
                </form>
            </div>
        </div>
    </div>