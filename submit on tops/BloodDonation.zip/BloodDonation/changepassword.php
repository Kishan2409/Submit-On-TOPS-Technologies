<div class="col-md-12">
    <div class="row">
        <!-- this is main -->
        <div class="col-md-12 mainfile">
            <div class="container">
                <br>
                <h3>
                    Change Password
                </h3>
                <hr>
                <div class="col-md-12">
                    <form method="post">
                    Enter Old Password<br>
                    <input type="password" name="oldp" placeholder="Enter Old Password"  class="mt-2 form-control"><br>
                    Enter New Password<br>
                    <input type="password" name="newp"  placeholder="Enter New Password" class="mt-2 form-control"><br>
                    Enter Confirm Password<br>
                    <input type="password" name="confp"  placeholder="Enter Confirm  Password" class="mt-2 form-control"><br>
                    <input type="submit" name="change" value="Change Password" class="float-end btn btn-danger">
                    </form>
                </div>

            </div>
        </div>
    </div>